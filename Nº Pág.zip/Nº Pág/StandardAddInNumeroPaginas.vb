﻿Imports System.Drawing
Imports System.IO
Imports System.Linq
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor
Imports stdoleIPictureDisp = stdole.IPictureDisp

<ComVisible(True)>
<Guid("B5C5E02A-FA9F-43AF-B442-8E823A8819AB")>
Public Class StandardAddInNumeroPaginas
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacao As AutomacaoNumeroPaginas
    Private botaoAtualizar As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacao
        End Get
    End Property

    Public Sub Activate(addInSiteObject As ApplicationAddInSite, firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacao = New AutomacaoNumeroPaginas(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions

            ' === Criar botão ===
            Try
                botaoAtualizar = DirectCast(controlDefs.Item("MyCompany_NumeroPaginas"), ButtonDefinition)
            Catch
                botaoAtualizar = controlDefs.AddButtonDefinition(
                    "Atualizar Nº Pág",
                    "MyCompany_NumeroPaginas",
                    CommandTypesEnum.kEditMaskCmdType,
                    Me.GetType().GUID.ToString("B"),
                    "Atualiza o número das páginas de cada modelo do desenho",
                    "Atualizar Propriedade 'Nº Pág'")
            End Try

            AddHandler botaoAtualizar.OnExecute, AddressOf Botao_OnExecute

            ' === Adicionar botão na Ribbon ===
            Dim ribbonDraw As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Drawing")
            Dim tabTools As RibbonTab = ribbonDraw.RibbonTabs("id_TabTools")
            Dim painel As RibbonPanel = Nothing

            Try
                painel = tabTools.RibbonPanels.Item("PainelNumeroPaginas")
            Catch
                painel = tabTools.RibbonPanels.Add("Nº Páginas", "PainelNumeroPaginas", Me.GetType().GUID.ToString("B"))
            End Try

            Dim existe As Boolean = painel.CommandControls.OfType(Of CommandControl)().
                Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_NumeroPaginas")

            If Not existe Then
                painel.CommandControls.AddButton(botaoAtualizar, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message, "Add-In Nº Páginas", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Botao_OnExecute(Context As NameValueMap)
        Try
            _automacao.Executar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar automação: " & ex.Message, "Add-In Nº Páginas", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacao = Nothing
    End Sub

    Public Sub ExecuteCommand(commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

End Class
