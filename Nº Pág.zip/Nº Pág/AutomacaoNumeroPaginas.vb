﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class AutomacaoNumeroPaginas

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()
        Try
            ' Verifica se o documento atual é um desenho
            Dim oDoc As DrawingDocument = TryCast(_app.ActiveDocument, DrawingDocument)
            If oDoc Is Nothing Then
                MessageBox.Show("Este Add-In deve ser executado dentro de um documento de desenho (.IDW ou .DWG do Inventor).",
                                "Documento inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            Dim oSheets As Sheets = oDoc.Sheets
            Dim modelPages As New Dictionary(Of String, List(Of Integer))

            ' --- Criar barra de progresso ---
            Dim oProgressBar As Inventor.ProgressBar
            Dim oProgressSteps As Integer
            Dim oProgressStep As Integer = 0
            Dim oProgressStaticText As String = "Atualizando propriedades: passo "

            ' --- Primeiro loop: identificar modelos e páginas ---
            For sheetIndex As Integer = 1 To oSheets.Count
                Dim oSheet As Sheet = oSheets.Item(sheetIndex)

                For Each oView As DrawingView In oSheet.DrawingViews
                    If oView.ReferencedDocumentDescriptor IsNot Nothing AndAlso
                       oView.ReferencedDocumentDescriptor.ReferencedDocument IsNot Nothing Then

                        Dim oModelDoc As Document = oView.ReferencedDocumentDescriptor.ReferencedDocument
                        Dim oModelName As String = oModelDoc.DisplayName

                        If Not modelPages.ContainsKey(oModelName) Then
                            modelPages(oModelName) = New List(Of Integer)
                        End If

                        If Not modelPages(oModelName).Contains(sheetIndex) Then
                            modelPages(oModelName).Add(sheetIndex)
                        End If
                    End If
                Next
            Next

            ' --- Criar barra de progresso ---
            oProgressSteps = modelPages.Count
            oProgressBar = _app.CreateProgressBar(False, oProgressSteps, "Atualizando: Nº DA PÁGINA")
            oProgressBar.Message = oProgressStaticText & oProgressStep & " de " & oProgressSteps
            oProgressBar.UpdateProgress()

            ' --- Atualizar propriedade personalizada "Nº DA PÁGINA" ---
            For Each kvp As KeyValuePair(Of String, List(Of Integer)) In modelPages
                Dim modelName As String = kvp.Key
                Dim textoPaginas As String = AgruparPaginas(kvp.Value)

                Try
                    ' Obter referência ao documento do modelo
                    Dim modelDoc As Document = _app.Documents.OfType(Of Document)().
                        FirstOrDefault(Function(d) d.DisplayName = modelName)

                    ' Se o modelo não estiver aberto, tentar abrir
                    If modelDoc Is Nothing Then
                        modelDoc = _app.Documents.Open(System.IO.Path.Combine(oDoc.Path, modelName))
                    End If

                    ' Obter conjunto de propriedades personalizadas
                    Dim oPropSet As PropertySet = modelDoc.PropertySets.Item("Inventor User Defined Properties")
                    Dim oProp As [Property] = Nothing

                    ' Tentar atualizar ou criar a propriedade
                    Try
                        oProp = oPropSet.Item("Nº DA PÁGINA")
                        oProp.Value = textoPaginas
                    Catch
                        oPropSet.Add(textoPaginas, "Nº DA PÁGINA")
                    End Try

                    ' Salvar o modelo após atualização
                    modelDoc.Save()

                Catch ex As Exception
                    MessageBox.Show("Erro ao atualizar propriedades para o modelo: " & modelName & vbCrLf & ex.Message)
                End Try

                ' Atualizar barra de progresso
                oProgressStep += 1
                oProgressBar.Message = oProgressStaticText & oProgressStep & " de " & oProgressSteps
                oProgressBar.UpdateProgress()
            Next

            oProgressBar.Close()
            MessageBox.Show("Propriedade 'Nº DA PÁGINA' atualizada com sucesso.", "Inventor Add-In", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Erro: " & ex.Message, "Inventor Add-In", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function AgruparPaginas(paginas As List(Of Integer)) As String
        If paginas Is Nothing OrElse paginas.Count = 0 Then Return ""

        paginas.Sort()
        Dim resultado As New List(Of String)
        Dim inicio As Integer = paginas(0)
        Dim fim As Integer = paginas(0)

        For i As Integer = 1 To paginas.Count - 1
            If paginas(i) = fim + 1 Then
                fim = paginas(i)
            Else
                If inicio = fim Then
                    resultado.Add(CStr(inicio))
                Else
                    resultado.Add(inicio & "-" & fim)
                End If
                inicio = paginas(i)
                fim = paginas(i)
            End If
        Next

        If inicio = fim Then
            resultado.Add(CStr(inicio))
        Else
            resultado.Add(inicio & "-" & fim)
        End If

        Return String.Join(",", resultado)
    End Function

End Class
